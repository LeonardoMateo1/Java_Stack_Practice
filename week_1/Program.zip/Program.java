public class Program {
    public static void main(String[] args) {
        System.out.println("My Name is Leonardo Mateo");
        System.out.println("I am 21 years old");
        System.out.println("My hometown is Naples, Florida");
    }
}